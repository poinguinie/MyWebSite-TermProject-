def Adv(level, hp, money):
    monsters = []
    monster_type = randint(1, 3)
    monster = open("monster.txt")
    for i in monster:
        (mon_type, name, level_1, level_2, level_3) = i.split()
        if monster_type == int(mon_type):
            monsters = [name, level_1, level_2, level_3]
            print(monsters[0] + "가 나타났다!")
            HP_count = "nobody died"
            if level == 1:
                HP = int(monsters[1])
            elif level == 2:
                HP = int(monsters[2])
            elif level == 3:
                HP = int(monsters[3])
            print("몬스터 레벨: " + str(level) + ", 야생 몬스터 체력: " + str(HP))
            while HP_count != 'someone died':
                print(skills)
                skill_num_1 = input("""원하시는 스킬을 사용하여 주세요!(숫자입력)
""")
                gain_money = 0
                gain_exp = 0
                number = int(skill_num_1)
                skills_num = []
                skill_text = open("skill.txt")
                for i in skill_text:
                    (num, mon_1, mon_2, me_1, me_2) = i.split()
                    if number == int(num):
                        num_1 = number - 1
                        print(skills[num_1] + """이 사용되었습니다!
""")
                        Attack_To_monster = randint(int(mon_1), int(mon_2))
                        Attack_To_me = randint(int(me_1), int(me_2))
                        if Attack_To_monster >= 55:
                            print("""
크리티컬!!
""")
                        HP = HP - Attack_To_monster
                        hp = hp - Attack_To_me
                        print("야생 몬스터의 남은 체력: " + str(HP) + ", 나의 몬스터의 남은 체력: " + str(hp) + """
""")

                        if hp <= 0:
                            print("""YOU DIED!
""")
                            HP_count = "someone died"
                        if HP <= 0:
                            HP_count = "someone died"
                            gain_money = randint(100, 500)
                            gain_exp = randint(50, 70)
                            print("몬스터가 쓰러졌다! " + str(gain_exp) + "만큼의 경험치와 " + str(gain_money) + """만큼의 골드를 얻었다!
""")

    return hp, gain_money, gain_exp