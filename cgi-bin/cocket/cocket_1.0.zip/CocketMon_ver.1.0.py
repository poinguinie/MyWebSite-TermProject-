#20184070 컴퓨터공학과 이지호
#임의의 프로그램

print("20184070 컴퓨터공학과 이지호")

from random import randint
from pygame import mixer
from shop import *
from adv import *
from skill import *
from dead import *

class my_monster_1():
    name = ""
    exp = ''
    money = ''
    hp = ''
    level = ''

    def __init__(self,nm,ex,mn,hp_1,lvl):
        self.name = nm
        self.exp = ex
        self.money = mn
        self.hp = hp_1
        self.level = lvl

mixer.init()
mixer.music.load("pocketmon_select.mp3")
mixer.music.play(-1)

my_monster = input("""당신의 몬스터를 선택하세요.
1. 꼬부기
2. 파이리
3. 이상해씨
(이름을 입력해주세요)
""")
my_monster = my_monster_1(my_monster,0,0,0,1)
my_monster_file = open("my_monster.txt")
for read in my_monster_file:
    (name, HP, skill_1, skill_2, skill_3) = read.split()
    if name == my_monster.name:
        print(my_monster.name + """가 골라졌습니다!
""")
        skills = [skill_1, skill_2, skill_3]
        my_monster.hp = int(HP)

ending = 0
while ending != 1 :
    mixer.stop()
    mixer.music.load("home.mp3")
    mixer.music.play(-1)
    action_1 = input("""무엇을 하시겠습니까?
1. 수련 (소정의 경험치를 받을 수 있습니다.)
2. 모험 (몬스터가 위험에 빠질 수 있으나 대량의 경험치와 골드를 얻을 수 있습니다.
3. 상점 (회복약을 구입 할 수 있습니다.)
(숫자로 입력해주세요.)
""")
    action = int(action_1)

    if action == 1:
        gain = randint(1,10)
        my_monster.exp = my_monster.exp + gain
        print(str(gain) + "만큼의 경험치를 얻어 현재 경험치는 " + str(my_monster.exp))

    elif action == 2:
        mixer.stop()
        mixer.music.load("battle.mp3")
        mixer.music.play(-1)
        my_monster.hp, gain_money, gain_exp = Adv(my_monster.level,my_monster.hp,my_monster.money)
        my_monster.money = my_monster.money + gain_money
        my_monster.exp = my_monster.exp + gain_exp
        if my_monster.hp <= 0:
            ending = 1

    elif action == 3:
        mixer.stop()
        mixer.music.load("shop.mp3")
        mixer.music.play(-1)
        my_monster.money, my_monster.hp = shop(my_monster.money,my_monster.hp)
                       
    over = 100

    if my_monster.exp >= over:
        my_monster.level = my_monster.level + 1
        print("당신 포켓몬의 레벨이 " + str(my_monster.level) + "이 되었습니다!")
        my_monster.exp = my_monster.exp - 100
        my_monster.hp = my_monster.hp + 50
        over = over + 100
    if my_monster.level >= 4:
        ending = 1


if my_monster.level>=4:
    print(my_monster.name + "가 성인이 되어 독립을 합니다. 키워주셔서 감사하다고 " +  my_monster.name + "가 인사를 합니다.")

else:
    print("포켓몬 " + my_monster.name + "가 당신의 혹사로 인하여 죽었습니다.")