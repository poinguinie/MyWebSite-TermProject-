def skill(skill_num_1, HP, hp, HP_count):
    gain_money = 0
    gain_exp = 0
    number = int(skill_num_1)
    skills_num = []
    skill_text = open("skill.txt")
    for i in skill_text:
        (num, mon_1, mon_2, me_1, me_2) = i.split()
        if number == int(num):
            num_1 = number - 1
            print(skills[num_1] + """이 사용되었습니다!
""")
            Attack_To_monster = randint(int(mon_1), int(mon_2))
            Attack_To_me = randint(int(me_1), int(me_2))
            if Attack_To_monster >= 55:
                print("""
크리티컬!!
""")
            HP = HP - Attack_To_monster
            hp = hp - Attack_To_me
            print("야생 몬스터의 남은 체력: " + str(HP) + ", 나의 몬스터의 남은 체력: " + str(hp) + """
""")

            if hp <= 0:
                print("""YOU DIED!
""")
                HP_count = "someone died"
            if HP <= 0:
                HP_count = "someone died"
                gain_money = randint(100, 500)
                gain_exp = randint(50, 70)
                print("몬스터가 쓰러졌다! " + str(gain_exp) + "만큼의 경험치와 " + str(money) + """만큼의 골드를 얻었다!
""")
                return HP, hp, gain_money, gain_exp, HP_count