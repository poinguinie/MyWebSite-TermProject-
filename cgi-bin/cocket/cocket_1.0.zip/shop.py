def shop(money,hp):
    print("""
상점에 어서오세요!""")
    print("""
현재 가지고 있는 골드: """ + str(money))
    choice = input("""
숫자를 입력하여주세요!
1.체력약 (소) : 20만큼의 체력 : 299골드
2.체력약 (중) : 50만큼의 체력 : 499골드
3.체력약 (특) : 100만큼의 체력 : 999골드
""")
    shop_txt = open("shop.txt")
    for i in shop_txt:
        (number, price, hill) = i.split()
        if choice == number:
            if money >= int(price):
                money = money - int(price)
                hp = hp + int(hill)
                print("""
현재 골드""" + str(money) + """
현재 체력""" + str(hp) + """
""")
            else:
                print("돈이 부족합니다!")

    return money,hp