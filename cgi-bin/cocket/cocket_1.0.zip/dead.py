def who_dead(HP,hp,HP_count):
    gain_money = 0
    gain_exp = 0
    if hp <= 0:
        print("""YOU DIED!
""")
        HP_count = "someone died"
    if HP <= 0:
        HP_count = "someone died"
        gain_money = randint(100,500)
        gain_exp = randint(50,70)
        print("몬스터가 쓰러졌다! " + str(gain_exp) + "만큼의 경험치와 " + str(money) + """만큼의 골드를 얻었다!
""")
        return hp, gain_money, gain_exp, HP_count